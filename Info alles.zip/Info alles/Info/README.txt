README
---------------------------------------------------------------------------------------
Jede Aufgabe ist einfach in dem dazugehörigen Ordner abgespeichert.
Ausserdem gibt es zu jeder Fragestellung eine Notepadnotiz welche denn Sinn erklärt
und/oder Gefragte Informationen wiedergibt